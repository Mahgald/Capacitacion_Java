package com.captton.mvcapp.data;

public interface IReunionDAO {

}
