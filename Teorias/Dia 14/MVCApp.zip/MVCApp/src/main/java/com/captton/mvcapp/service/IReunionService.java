package com.captton.mvcapp.service;

public interface IReunionService {

}
