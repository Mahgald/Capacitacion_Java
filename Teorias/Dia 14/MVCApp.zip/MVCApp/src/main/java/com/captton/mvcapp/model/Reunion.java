package com.captton.mvcapp.model;

public class Reunion {

}
