package com.captton.mvcapp.service;

public class ReunionService implements IReunionService {

}
