package com.captton.mvcapp.data;

import java.util.List;

import com.captton.mvcapp.model.Departamento;

public interface IDepartamentoDAO {

	public List<Departamento> ListarDepartamentos();
}
