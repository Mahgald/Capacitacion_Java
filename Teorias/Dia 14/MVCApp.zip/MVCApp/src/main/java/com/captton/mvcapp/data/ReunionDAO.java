package com.captton.mvcapp.data;

public class ReunionDAO implements IReunionDAO {

}
