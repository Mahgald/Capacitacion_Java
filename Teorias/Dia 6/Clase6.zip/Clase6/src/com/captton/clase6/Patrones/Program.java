package com.captton.clase6.Patrones;

public class Program
{

	public static void main(String[] args)
	{
	/*	Singleton s1 = Singleton.getInstancia();
		Singleton s2 = Singleton.getInstancia();
		Singleton s3 = Singleton.getInstancia();
		Singleton s4 = Singleton.getInstancia();
		*/
	//	System.out.println(s4.getContador());
		
		IPerro perroGrande = FactoryPerro.criarPerro("GRANde");
		
		System.out.println(perroGrande.comer());
		
	}

}
