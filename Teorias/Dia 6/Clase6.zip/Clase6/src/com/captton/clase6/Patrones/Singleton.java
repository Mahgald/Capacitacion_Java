package com.captton.clase6.Patrones;

public class Singleton
{
	private static Singleton instancia;
	//private static int contador;
	
	private Singleton()
	{
		//contador++;
	}
	
	public static Singleton getInstancia()
	{
		if(instancia == null)
		{
			instancia = new Singleton();
		}		
		return instancia;
	}
/*	
	public int getContador()
	{return contador;}
*/
}
