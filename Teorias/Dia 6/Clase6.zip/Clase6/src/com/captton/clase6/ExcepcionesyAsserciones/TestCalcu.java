package com.captton.clase6.ExcepcionesyAsserciones;

import static org.junit.Assert.*;
import org.junit.*;

public class TestCalcu
{
	
	@Test
	public void testDividir()
	{
		assertEquals(2, Calculadora.dividir(10, 6));
	}

}
