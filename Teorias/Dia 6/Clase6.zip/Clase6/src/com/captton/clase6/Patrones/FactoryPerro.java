package com.captton.clase6.Patrones;

public class FactoryPerro
{
	public static IPerro criarPerro(String criterio)
	{
		IPerro perro = null;
		criterio = criterio.toLowerCase();
		switch (criterio)
		{
		case "chico":
			perro = new Caniche();			
			break;

		case "mediano":
			perro = new Labrador();
			break;
			
		case "grande":
			perro = new Dogo();
			break;
		}
		return perro;
	}
}
