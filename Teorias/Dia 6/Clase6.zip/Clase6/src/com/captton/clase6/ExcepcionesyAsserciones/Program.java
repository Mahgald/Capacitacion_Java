package com.captton.clase6.ExcepcionesyAsserciones;

import java.util.Scanner;
import java.util.concurrent.ExecutionException;

public class Program
{

	public static void main(String[] args)
	{
		try
		{
			System.out.println("Ingrese un dividendo");
			
			Scanner sc = new Scanner(System.in);
			int valor = Integer.parseInt(sc.nextLine());
			
			int resultado = Calculadora.dividir(10, valor);
			
			System.out.println("el resultado es " + resultado);

		} 
		catch (NullPointerException e)
		{
			System.out.println(e.getMessage() +"No se inicializo la variable");
		}
		catch (NumberFormatException e)
		{
			System.out.println(e.getMessage() +" Argumentos invalidos");
		} 
		
		catch (Exception e)
		{
			System.out.println(e.getMessage() +" NO SE PUEDE DIVIDIR POR CERO");
		} 
		
				
	}

}
