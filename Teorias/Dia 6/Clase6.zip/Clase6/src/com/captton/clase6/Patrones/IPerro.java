package com.captton.clase6.Patrones;

public interface IPerro
{
	public String comer();
}
