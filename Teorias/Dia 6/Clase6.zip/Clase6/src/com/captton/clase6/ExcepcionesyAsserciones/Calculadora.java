package com.captton.clase6.ExcepcionesyAsserciones;

public class Calculadora
{
	public static int dividir(int numero1,int numero2)
	{
		return numero1 / numero2;
	}

}
