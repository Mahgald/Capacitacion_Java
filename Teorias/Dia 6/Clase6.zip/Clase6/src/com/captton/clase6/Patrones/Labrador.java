package com.captton.clase6.Patrones;

public class Labrador implements IPerro
{

	@Override
	public String comer()
	{
		return "Debe ser por dog chow";
	}

}
