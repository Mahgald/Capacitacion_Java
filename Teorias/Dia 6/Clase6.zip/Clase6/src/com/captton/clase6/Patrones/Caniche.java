package com.captton.clase6.Patrones;

public class Caniche implements IPerro
{

	@Override
	public String comer()
	{
		return "Morfo chaucha y palito";
	}

}
