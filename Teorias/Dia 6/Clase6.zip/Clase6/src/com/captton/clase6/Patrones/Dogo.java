package com.captton.clase6.Patrones;

public class Dogo implements IPerro
{

	@Override
	public String comer()
	{
		return "Morfo como un campeon";
	}
	
}
