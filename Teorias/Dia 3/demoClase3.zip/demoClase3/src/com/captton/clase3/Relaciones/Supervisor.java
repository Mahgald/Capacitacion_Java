package com.captton.clase3.Relaciones;

import java.util.ArrayList;

public class Supervisor
{
	private float salario;
	private String nombre;
	//AGREGACION
	private ArrayList<Empleado> listaEmpleadosACargo;
	//COMPOSICION
	private Proyecto proy;
	
	public Supervisor(String nombre, String nombreProyecto, float salario)
	{
		this.nombre= nombre;
		this.salario = salario;
		this.listaEmpleadosACargo = new ArrayList<>();
		this.proy = new Proyecto(nombreProyecto);
	}


	
	//ASOCIACION
	public String ingresarAlEdificio(TarjetaIdentificacion ti)
	{
		return this.nombre+ " - " + ti.autorizar();
	}
	
	//AGREGACION
	public void agregarEmpleado(Empleado emple)
	{
		this.listaEmpleadosACargo.add(emple);
	}
	
	public String hacerTrabajar()
	{
		StringBuilder str = new StringBuilder();
		
		for (Empleado empleado : listaEmpleadosACargo)
		{
			str.append(empleado.trabajar()+"\n");
		}
		return str.toString();
	}



	public float getSalario()
	{
		return salario;
	}



	public void setSalario(float salario)
	{
		if(this.proy.esExitoso(this))
		{
		this.salario += salario;
		}
		else
		{
			this.salario -= salario;
		}
	}



	public ArrayList<Empleado> getListaEmpleadosACargo()
	{
		return listaEmpleadosACargo;
	}



	public void setListaEmpleadosACargo(ArrayList<Empleado> listaEmpleadosACargo)
	{
		this.listaEmpleadosACargo = listaEmpleadosACargo;
	}



	public Proyecto getProy()
	{
		return proy;
	}



	public void setProy(Proyecto proy)
	{
		this.proy = proy;
	}
	
}
