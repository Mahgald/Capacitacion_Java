package com.captton.clase3.Relaciones;

public class TarjetaIdentificacion
{
	
	public String autorizar()
	{
		return "Acceso Autorizado";
	}
}
