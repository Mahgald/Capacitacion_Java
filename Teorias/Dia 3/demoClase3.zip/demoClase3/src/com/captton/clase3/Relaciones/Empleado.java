package com.captton.clase3.Relaciones;

public class Empleado
{
	String nombre;
	
	public Empleado(String nombre)
	{
		this.nombre = nombre;
	}
	
	public String trabajar()
	{
		return  this.nombre+" trabaja muy duro como un esclavo.. paguenme dinero =)";
	}

}
