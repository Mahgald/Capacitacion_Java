package com.captton.clase3.Relaciones;

public class Proyecto
{
	private String nombre;
	private boolean exitoso;
	
	public Proyecto(String nombreProyecto)
	{
		this.nombre = nombreProyecto;
		this.exitoso = false;
	}
	
	public boolean esExitoso(Supervisor sup)
	{
		if(sup.getListaEmpleadosACargo().size() > 2)
		{
			this.exitoso = true;
		}
		else
		{
			this.exitoso = false;
		}
		return this.exitoso;
	}
	
	
}
