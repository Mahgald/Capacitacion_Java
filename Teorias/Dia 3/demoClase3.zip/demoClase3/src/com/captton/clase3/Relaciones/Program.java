package com.captton.clase3.Relaciones;

public class Program
{

	public static void main(String[] args)
	{
		Supervisor sup = new Supervisor("Carlitos","Santander",30000);
		TarjetaIdentificacion ti = new TarjetaIdentificacion();
		Empleado emple1 = new Empleado("Silvio");
		Empleado emple2 = new Empleado("Gaston");
		Empleado emple3 = new Empleado("Fernando");
		

		//asociacion
		System.out.println(sup.ingresarAlEdificio(ti));
		
		//AGREGACION
		sup.agregarEmpleado(emple1);
		sup.agregarEmpleado(emple2);
		sup.agregarEmpleado(emple3);
		
		System.out.println(sup.hacerTrabajar());
		
		
		sup.setSalario(5000);
		
		System.out.println("El supervisor esta cobrando $"+sup.getSalario());
	}

}
