package com.captton.Clase2;

public class Alumno
{
	//atributo estatico o de clase
	private static int cantidadAlumnos;	
	
	//atributos de instancia
	private int legajo;
	private String nombre;
	private String apellido;
	private int edad;
	
	//constructor 
	public Alumno()
	{
		cantidadAlumnos++;
	}
	//contructor sobrecargador
	public Alumno(String nombre,String apellido, int legajo,int edad)
	{
		cantidadAlumnos++;
		this.nombre = nombre;
		this.apellido = apellido;
		this.legajo = legajo;
		this.edad = edad;		
	}
	
	//metodo de escritura
	public void asignarNombre(String nombre)
	{
		this.nombre = nombre;	
	}
	
	//metodo de lectura
	public String leerNombre()
	{
		return this.nombre;
	}
	
	
	//metodo estatico para atributos estaticos
	public static int conocerCantidadAlumnosEstatico()
	{
		return cantidadAlumnos;
	}

}
