package com.captton.Clase2;

import java.util.ArrayList;

public class Program
{

	public static void main(String[] args)
	{/*
		//INSTANCIACION
		Alumno alu1 = new Alumno();
		Alumno alu2 = new Alumno();
		
		alu1.nombre = "pepe";
		alu1.apellido ="luis";
		alu1.edad = 28;
		
		String datos = String.format("Alumno %s,%s de %d de edad", alu1.nombre,alu1.apellido,alu1.edad);
		System.out.println(datos);
		
		//System.out.println(alu2.apellido);
		
		alu2.asignarNombre("Leandro");
		
		String nombreDelAlumno = alu2.leerNombre();
		
		System.out.println(nombreDelAlumno);
		
		
		/*Calculadora calcu = new Calculadora();
		
		calcu.sumar(2 , 7.5f);
		*/
		
			/*			
		
		System.out.println(alu1.leerNombre());
		
		alu1.conocerCantidadAlumnosEstatico();
		
		*/
		Alumno alu1 = new Alumno("Leandro","Baldassarre",151851,28);

		ArrayList<Alumno> listaAlumnos = new ArrayList<>();
		listaAlumnos.add(alu1);
		
		for (Alumno item : listaAlumnos)
		{
			System.out.println(item.leerNombre());
		}		
		
		
		
		
		ArrayList<String> listaNombres = new ArrayList<>();
		
		listaNombres.add("pepe");
		listaNombres.add("juan");
		listaNombres.add("sebastian");
		
		
		for (String item : listaNombres)
		{
			System.out.println(item);
		}
		
		if(listaNombres.contains("pepe"))
		{
			System.out.println("pepe esta en "+listaNombres.indexOf("pepe"));
			
		}
		else
		{
			System.out.println("pepe no esta");
		}

		for (String item : listaNombres)
		{		
			System.out.println(item);			
		}
		//System.out.println(listaNombres);
		
		
	}

}
