package com.captton.Clase2;

public class Calculadora
{
	public int sumar(int entero1, int entero2)
	{
		return entero1+entero2;
	}
	
	public float sumar(float numero1, float numero2)
	{
		return numero1+numero2;
	}
	
	public int sumar(int entero1, int entero2, int entero3)
	{
		return entero1+entero2+entero3;
	}
	public int sumar(float entero1,int entero2)
	{
		return (int)entero1+entero2;
	}
	
	public int sumar(int numero1, float numero2)
	{
		return numero1+(int)numero2;
	}
	
	private int restar(int numero1, float numero2)
	{
		return numero1-(int)numero2;
	}
}
