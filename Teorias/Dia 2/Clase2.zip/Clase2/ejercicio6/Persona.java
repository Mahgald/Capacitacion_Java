package com.captton.Clase2.ejercicio6;

public class Persona implements Comparable<Persona>
{
	private String nombre;
	private Integer dni;
	private String apellido;
	
	public Persona(String nombre, String apellido, int dni)
	{
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		
	}

	@Override
	public int compareTo(Persona o)
	{
		int valor =  this.dni.compareTo(o.dni);
		return valor;
	}

	public String getNombre()
	{
		return nombre;
	}

	public void setNombre(String nombre)
	{
		this.nombre = nombre;
	}

	public Integer getDni()
	{
		return dni;
	}

	public void setDni(Integer dni)
	{
		this.dni = dni;
	}

	public String getApellido()
	{
		return apellido;
	}

	public void setApellido(String apellido)
	{
		this.apellido = apellido;
	}
}
