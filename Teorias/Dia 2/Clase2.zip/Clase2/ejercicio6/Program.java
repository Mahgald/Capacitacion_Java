package com.captton.Clase2.ejercicio6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Program
{/*
	Declarar una lista y pedir por consola
	10 valores separados por coma para la misma.
	Luego de cargar la lista,
	utilizar los metodos provistos por las mismas para ordenarla 
	y mostrar uno a uno los valores contenidos. 
	Pueden ser numeros, palabras, etc.
	*/
	public static void main(String[] args)
	{
		/*
		ArrayList<String> lista = new ArrayList<>();
		System.out.println("Ingrese 10 palabras separados por coma");
		Scanner sc = new Scanner(System.in);
		
		String linea = sc.nextLine();
		linea = linea.replace(" ", "");
		String[] palabrasEnArray = linea.split(",");
		
		for (int i = 0; i < palabrasEnArray.length-1; i++)
		{
			lista.add(palabrasEnArray[i]);
		}
		
		Collections.sort(lista);
		
		for (String item : lista)
		{
			System.out.println(item);
		}	
		*/
		ArrayList<Persona> listaPersona = new ArrayList<>();
		
		listaPersona.add(new Persona("Esteban", "Quito", 35982485));
		listaPersona.add(new Persona("Juan", "Lalala", 15268585));
		listaPersona.add(new Persona("Cosme", "Fulanito", 31368956));
		
		Collections.sort(listaPersona);
		
		for (Persona persona : listaPersona)
		{
			System.out.println(persona.getNombre()+" " + persona.getDni());
		}

	}

}
