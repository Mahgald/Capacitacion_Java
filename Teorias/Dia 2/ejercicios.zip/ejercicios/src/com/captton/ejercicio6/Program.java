package com.captton.ejercicio6;

import java.util.Scanner;

public class Program
{
/*A partir de un array de elementos,
 buscar si un valor se encuentra dentro del mismo.
 En caso que se encuentre, mostrar 
 la posición en la cual fue encontrado. De lo contrario, mostrar -1
*/
	public static void main(String[] args)
	{
		System.out.println("Ingrese nombre a buscar");
		Scanner sc = new Scanner(System.in);
		String nombre = sc.nextLine();
		nombre = nombre.toLowerCase();
		int index = -1;
		
		String[] listaNombres = {"pepe","carlos","esteban","julieta","ramiro"};
		
		for (int i = 0; i < listaNombres.length; i++)
		{
			if(listaNombres[i].equals(nombre))
			{
				index = i+1;
			}
		}
		System.out.println(index);
	}

}
