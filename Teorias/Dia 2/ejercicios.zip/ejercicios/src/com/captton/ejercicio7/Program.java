package com.captton.ejercicio7;

public class Program
{
	/*
	  Partiendo de un array de números declarado estaticamente,
	  ordenar el mismo y mostrar el resultado del array ordenado
	*/
	public static void main(String[] args)
	{
		int[] numerosDeclarados = {22,39,24,7,28,65,15,42,35,11};
		int aux = 0;
		
		for (int i = 0; i < numerosDeclarados.length-1; i++)
		{
			for (int j = i+1; j < numerosDeclarados.length; j++)
			{
				if(numerosDeclarados[i] > numerosDeclarados[j])
				{
					aux = numerosDeclarados[i];
					numerosDeclarados[i] = numerosDeclarados[j];
					numerosDeclarados[j] = aux;
				}
			}			
		}
		
		for (int i = 0; i < numerosDeclarados.length-1; i++)
		{
			System.out.println(numerosDeclarados[i]);
		}
		
	}

}
