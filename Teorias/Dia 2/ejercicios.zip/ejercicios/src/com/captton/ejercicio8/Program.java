package com.captton.ejercicio8;

import java.util.Scanner;

public class Program
{
	/*
Pidiendo una palabra o frase por consola comprobar 
si la misma es un palíndromo o no. Informar el resultado.

Los palindromos son aquellas palabras que se leen de igual manera 
de izquierda a derecha y de  derecha a izquierda. 
Cuando hablamos de frases, no se cuentan las puntuaciones 
ni los espacios.

Ejemplo de palíndromo: Neuquen, Anita lava la tina  
	  */

	public static void main(String[] args)
	{
		System.out.println("Ingrese una frase");
		Scanner sc = new Scanner(System.in);
		String frase = sc.nextLine();
		String fraseInvertida = "";
		
		frase = frase.toLowerCase();		
		frase = frase.replace(" ", "");			
		
		for (int i = frase.length()-1; i >= 0 ; i--)
		{
			fraseInvertida += frase.charAt(i);
			//fraseInvertida = fraseInvertida + frase.charAt(i);
		}
		
		if(frase.equals(fraseInvertida))
		{
			System.out.println("Es un palindromo");
		}
		else
		{
			System.out.println("No es un palindromo");
		}
		
		
	}

}
