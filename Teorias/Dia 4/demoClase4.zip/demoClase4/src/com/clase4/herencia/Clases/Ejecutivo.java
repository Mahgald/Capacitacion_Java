package com.clase4.herencia.Clases;

public class Ejecutivo extends Empleado
{

	public Ejecutivo(String nombre, String apellido, float sueldo)
	{
		super(nombre, apellido, sueldo);
		
	}

	@Override
	public String trabajar()
	{
		return "Yo ? Trabajar ? Qué es eso ?";
	}

	@Override
	public String toString()
	{
		return "Soy "+this.nombre+this.apellido+" pá";
	}


}
