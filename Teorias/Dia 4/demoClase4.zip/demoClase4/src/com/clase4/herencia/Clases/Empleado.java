package com.clase4.herencia.Clases;

public abstract class Empleado
{
	protected String nombre;
	protected String apellido;
	protected float sueldo;	
	
	public Empleado(String nombre,String apellido,float sueldo)
	{
		this.apellido = apellido;
		this.nombre = nombre;
		this.sueldo = sueldo;
	}
	
	public abstract String trabajar();
	
	public String salirAComer(String comida)
	{
		return "Estoy comiendo "+comida;
	}
	protected void cobrarAguinaldo()
	{	
		this.sueldo +=5000;		
	}
}
