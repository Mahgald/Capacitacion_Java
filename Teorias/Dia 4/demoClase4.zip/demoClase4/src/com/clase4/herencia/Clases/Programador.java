package com.clase4.herencia.Clases;

public class Programador extends Empleado
{
	private int cantidadHorasTrabajadas;

	public Programador(String nombre, String apellido, float sueldo,int horas)
	{
		super(nombre, apellido, sueldo);
		this.cantidadHorasTrabajadas = horas;
	}

	@Override
	public String trabajar()
	{
		return "Me mulean a 4 manos";
	}
	
	@Override
	public String salirAComer(String comida)
	{
		return "Yo no tengo tiempo pa comer";	
	}
	
	@Override
	protected void cobrarAguinaldo()
	{
		super.cobrarAguinaldo();
	}

}
