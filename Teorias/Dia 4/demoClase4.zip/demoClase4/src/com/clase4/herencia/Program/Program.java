package com.clase4.herencia.Program;

import java.util.ArrayList;

import com.clase4.herencia.Clases.Ejecutivo;
import com.clase4.herencia.Clases.Programador;
import com.clase4.interfazYPoliformos.Animal;
import com.clase4.interfazYPoliformos.Gato;
import com.clase4.interfazYPoliformos.IDomestico;
import com.clase4.interfazYPoliformos.Perro;
import com.clase4.interfazYPoliformos.Tigre;

public class Program
{

	public static void main(String[] args)
	{
		/*
		Ejecutivo eje = new Ejecutivo("El", "Pepo", 30000);
		System.out.println(eje.toString());
		System.out.println(eje.trabajar());
		System.out.println(eje.salirAComer("Salmon"));
		Programador progra = new Programador("Doc", "Brown", 25000, 46);
		
		System.out.println(progra.trabajar());
		System.out.println(progra.salirAComer("Bifecito"));
		*/
			
		ArrayList<Animal> listaAnimales = new ArrayList<>();
		Perro bobi = new Perro("Firulais", 10);
		Gato vicky = new Gato("Mauri", 65);
		Tigre tiger = new Tigre("Kellogs", 23);
		
		
		listaAnimales.add(bobi);
		listaAnimales.add(vicky);
		listaAnimales.add(tiger);
		
		ArrayList<IDomestico> listaDomesticos = new ArrayList<>();
		listaDomesticos.add(vicky);
		listaDomesticos.add(bobi);
		
		/*
		for (IDomestico bichos : listaDomesticos)
		{
			System.out.println(bichos.sacarAPasear());
		}
		*/
		for (Animal bichito : listaAnimales)
		{
			
			if(bichito.getClass().equals(Perro.class))
			{
				System.out.println(bichito.comer("dog chow"));
				System.out.println(((Perro)bichito).sacarAPasear());
			}
			else
			{
				System.out.println(bichito.comer("lo que venga"));
			}
		}
		
	}

}

