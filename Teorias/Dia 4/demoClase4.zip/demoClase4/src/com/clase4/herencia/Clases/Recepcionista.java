package com.clase4.herencia.Clases;

public class Recepcionista extends Empleado
{

	public Recepcionista(String nombre, String apellido, float sueldo)
	{
		super(nombre, apellido, sueldo);
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public String trabajar()
	{
		return "pepe";
	}
	

}
