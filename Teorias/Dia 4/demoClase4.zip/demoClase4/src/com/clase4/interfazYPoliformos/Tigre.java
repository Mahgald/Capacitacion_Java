package com.clase4.interfazYPoliformos;

public class Tigre extends Animal
{

	public Tigre(String nombre, int edad)
	{
		super(nombre, edad);
	}

	@Override
	public String comer(String morfi)
	{
		return "Comiendo "+ morfi;
	}
	
}
