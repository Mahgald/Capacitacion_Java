package com.clase4.interfazYPoliformos;

public class Perro extends Animal implements IDomestico
{

	public Perro(String nombre, int edad)
	{
		super(nombre, edad);
	}

	@Override
	public String comer(String morfi)
	{
		return "Comiendo "+morfi +" y su popo está dura" ;
	}

	@Override
	public String sacarAPasear()
	{	
		return "Saliendo al parque";
	}

}
