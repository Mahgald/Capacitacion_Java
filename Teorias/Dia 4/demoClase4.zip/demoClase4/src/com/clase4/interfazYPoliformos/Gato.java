package com.clase4.interfazYPoliformos;

public class Gato extends Animal implements IDomestico
{

	public Gato(String nombre, int edad)
	{
		super(nombre, edad);
	}

	@Override
	public String sacarAPasear()
	{
			return "Yo salgo solo, porque soy Macri";
	}

	@Override
	public String comer(String morfi)
	{
		return "8 de cada 10 Macris prefieren "+morfi;
	}
	

}
