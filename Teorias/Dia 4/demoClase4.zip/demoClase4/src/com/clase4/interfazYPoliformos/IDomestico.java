package com.clase4.interfazYPoliformos;

public interface IDomestico
{
	public String sacarAPasear();

}
